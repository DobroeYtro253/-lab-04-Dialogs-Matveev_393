package com.example.window;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    CheckBox[] chk = new CheckBox[4];
    EditText[] num = new  EditText[4];
    TextView[] txt = new TextView[4];
    float[] price = new float[4];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num[0] = findViewById(R.id.num1);
        num[1] = findViewById(R.id.num2);
        num[2] = findViewById(R.id.num3);
        num[3] = findViewById(R.id.num4);

        txt[0] = findViewById(R.id.txt1);
        txt[1] = findViewById(R.id.txt2);
        txt[2] = findViewById(R.id.txt3);
        txt[3] = findViewById(R.id.txt4);

        txt[0].setText("100");
        txt[1].setText("70");
        txt[2].setText("150");
        txt[3].setText("50");



        chk[0] = findViewById(R.id.box1);
        chk[1] = findViewById(R.id.box2);
        chk[2] = findViewById(R.id.box3);
        chk[3] = findViewById(R.id.box4);
    }

    public void on_calc(View v)
    {
          try {
              float sum = 0.0f;

              for(int i = 0; i < 4; i++)
              {
                  if (chk[i].isChecked())
                  {
                      int q = Integer.parseInt(num[i].getText().toString());
                      Integer a = Integer.valueOf(txt[i].getText().toString());
                      float val = q * a;
                      sum += val;
                  }

              }
              String str = Float.toString(sum);
              Toast.makeText(this, str , Toast.LENGTH_SHORT).show();
          }
          catch (Exception e)
          {
              Toast.makeText(this, "Ошибка" , Toast.LENGTH_SHORT).show();
          }

    }
}